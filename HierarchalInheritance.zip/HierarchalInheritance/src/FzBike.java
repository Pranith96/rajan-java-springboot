
public class FzBike extends Bike{

	public void tire() {
		System.out.println("Tire");
	}
}
