
public class MotorBike extends Bike{

	public void petrolTank() {
		System.out.println("petrol tank");
	}

	public void mirror() {
		System.out.println("Mirror");
	}
}
