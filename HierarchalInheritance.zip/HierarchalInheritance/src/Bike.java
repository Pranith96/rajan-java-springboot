
public class Bike {

	public void engine() {
		System.out.println("Engine");
	}
	
	public void breaks() {
		System.out.println("beraks");
	}
}
