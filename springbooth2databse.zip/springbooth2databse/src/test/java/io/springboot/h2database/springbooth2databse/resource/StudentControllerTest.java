package io.springboot.h2database.springbooth2databse.resource;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.springboot.h2database.springbooth2database.entity.Student;
import io.springboot.h2database.springbooth2database.service.StudentServiceImpl;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc

public class StudentControllerTest {

	@MockBean
	StudentServiceImpl studentService;

	@Autowired
	private WebApplicationContext context;

	@Autowired
	MockMvc mockMvc;

	ObjectMapper objectMapper = new ObjectMapper();

	//@BeforeEach
	//public void setUp() {
	//	this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	//}

	@Test
	public void testCreateStudent() throws Exception {
		Student student = new Student();
		student.setStudentId(1);
		student.setName("Pranith");
		student.setCourse("Java");
		student.setCollege("ABCDE");

		String response = "Data Saved";

		String jsonRequest = objectMapper.writeValueAsString(response);

		Mockito.when(studentService.createStudent(student)).thenReturn(response);
		mockMvc.perform(MockMvcRequestBuilders.post("/student/save").contentType(MediaType.APPLICATION_JSON)
				.content(jsonRequest)).andExpect(status().isOk()).andReturn();
	}

}
