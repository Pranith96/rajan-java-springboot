insert into student (name,college,course) values ('pranith','INDU','ECE');
insert into student (name,college,course) values ('Sandeep','CVR','CSE');
insert into student (name,college,course) values ('Harsha','MLR','MECH');
insert into student (name,college,course) values ('Vikram','BNR','EEE');
