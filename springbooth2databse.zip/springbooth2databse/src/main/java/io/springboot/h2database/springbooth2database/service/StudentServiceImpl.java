package io.springboot.h2database.springbooth2database.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.springboot.h2database.springbooth2database.entity.Student;
import io.springboot.h2database.springbooth2database.repository.StudentRepository;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepository studentRepository;

	@Override
	public String createStudent(Student student) {

		studentRepository.save(student);

		return "Data Saved";
	}

	@Override
	public Student getStudentById(Integer id) throws Exception {

		Optional<Student> studentResponse = studentRepository.findById(id);

		if (!studentResponse.isPresent()) {
			throw new Exception("Data not found");
		}

		return studentResponse.get();
	}

	@Override
	public List<Student> getAllStudent() throws Exception {
		return null;

	}

	@Override
	public Student getStudentByName(String name) throws Exception {
		return studentRepository.findByName(name).orElseThrow(() -> new Exception("Data Not found"));
	}

	@Override
	public Student getStudentByIdAndName(Integer id, String name) throws Exception {
		Optional<Student> studentResponse = studentRepository.findByIdAndName(id, name);

		if (!studentResponse.isPresent()) {
			throw new Exception("Data not found");
		}

		return studentResponse.get();
	}

	@Override
	public Student getStudentByCourse(String course) throws Exception {
		return studentRepository.findByCourse(course).orElseThrow(() -> new Exception("Data Not found"));
	}

	@Override
	public Student getStudentByCollege(String college) throws Exception {

		return studentRepository.findByCollege(college).orElseThrow(() -> new Exception("Data Not found"));
	}

	@Override
	public Student getStudentIdName(Integer id) throws Exception {
		return studentRepository.findById(id).orElseThrow(() -> new Exception("Data Not found"));

	}

	@Override
	public List<Student> fetchAllStudent() throws Exception {
		List<Student> studentResponse = studentRepository.findAll();
		if (studentResponse == null) {
			throw new Exception("Data not found");
		}
		return studentResponse;
	}
}
