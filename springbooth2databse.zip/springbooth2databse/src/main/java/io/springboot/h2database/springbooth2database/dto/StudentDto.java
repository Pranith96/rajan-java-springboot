package io.springboot.h2database.springbooth2database.dto;

import lombok.Data;

@Data
public class StudentDto {

	private int studentId;
	private String name;

}
