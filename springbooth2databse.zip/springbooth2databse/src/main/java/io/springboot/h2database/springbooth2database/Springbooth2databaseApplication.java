package io.springboot.h2database.springbooth2database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbooth2databaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springbooth2databaseApplication.class, args);
	}

}
	