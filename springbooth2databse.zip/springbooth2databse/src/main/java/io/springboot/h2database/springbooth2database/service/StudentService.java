package io.springboot.h2database.springbooth2database.service;

import java.util.List;

import io.springboot.h2database.springbooth2database.dto.StudentDto;
import io.springboot.h2database.springbooth2database.entity.Student;

public interface StudentService {

	String createStudent(Student student);

	Student getStudentById(Integer id) throws Exception;

	List<Student> getAllStudent() throws Exception;

	Student getStudentByName(String name) throws Exception;

	Student getStudentByIdAndName(Integer id, String name) throws Exception;

	Student getStudentByCourse(String course) throws Exception;

	Student getStudentByCollege(String college) throws Exception;

	Student getStudentIdName(Integer id) throws Exception;

	List<Student> fetchAllStudent() throws Exception;

}
