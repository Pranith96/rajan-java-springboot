package io.springboot.h2database.springbooth2database.Util;

public class Student2 {

	private int studentId;
	private String name;
	private String college;
	private String course;

	public Student2() {
	}

	public Student2(int studentId, String name, String college, String course) {
		this.studentId = studentId;
		this.name = name;
		this.college = college;
		this.course = course;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "Student2 [college=" + college + ", course=" + course + ", name=" + name + ", studentId=" + studentId
				+ "]";
	}

}