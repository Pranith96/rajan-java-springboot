package io.springboot.h2database.springbooth2database.resource;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.springboot.h2database.springbooth2database.dto.StudentDto;
import io.springboot.h2database.springbooth2database.entity.Student;
import io.springboot.h2database.springbooth2database.service.StudentService;

@RestController
@RequestMapping(value = "/student")
public class StudentController {

	//@Autowired
	//ModelMapper mapper;
	
	//@Value("${server.port}")
	//private String port;

	@Autowired
	//@Qualifier("ghj")
	StudentService studentService;

	@PostMapping("/save")
	public ResponseEntity<String> createStudent(@RequestBody Student student) {
		String response = studentService.createStudent(student);
		return ResponseEntity.ok(response);
	}

	@GetMapping("/fetch/id/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable("id") Integer id) throws Exception {
		Student studentResponse = studentService.getStudentById(id);
		return ResponseEntity.status(HttpStatus.OK).body(studentResponse);
	}

	@GetMapping("/fetchAll")
	public ResponseEntity<List<Student>> getAllStudent() throws Exception {
		List<Student> studentResponse = studentService.getAllStudent();
		return ResponseEntity.status(HttpStatus.OK).body(studentResponse);
	}

	@GetMapping("/fetch/name/{name}")
	public ResponseEntity<Student> getStudentByName(@PathVariable("name") String name) throws Exception {
		Student studentResponse = studentService.getStudentByName(name);
		return ResponseEntity.status(HttpStatus.OK).body(studentResponse);
	}

	@GetMapping("/fetch/{id}/{name}")
	public ResponseEntity<Student> getStudentByIdAndName(@PathVariable("id") Integer id,
			@PathVariable("name") String name) throws Exception {
		Student studentResponse = studentService.getStudentByIdAndName(id, name);
		return ResponseEntity.status(HttpStatus.OK).body(studentResponse);

	}

	@GetMapping("/fetch/course/{course}")
	public ResponseEntity<Student> getStudentByCourse(@PathVariable("course") String course) throws Exception {
		Student studentResponse = studentService.getStudentByCourse(course);
		return ResponseEntity.status(HttpStatus.OK).body(studentResponse);
	}

	@GetMapping("/fetch/college/{college}")
	public ResponseEntity<Student> getStudentByCollege(@PathVariable("college") String college) throws Exception {
		Student studentResponse = studentService.getStudentByCollege(college);
		return ResponseEntity.status(HttpStatus.OK).body(studentResponse);
	}

	// Example for using model mapper and setting dto's
	@GetMapping("/fetch/id/name/{id}")
	public ResponseEntity<StudentDto> getStudentIdName(@PathVariable("id") Integer id) throws Exception {
		Student studentData = studentService.getStudentIdName(id);
		StudentDto studentDto = new StudentDto(); //mapper.map(studentData, StudentDto.class);
		return ResponseEntity.status(HttpStatus.OK).body(studentDto);
	}

	@GetMapping("/fetch/all")
	public ResponseEntity<List<StudentDto>> fetchAllStudent() throws Exception {
		//List<StudentDto> studentResponse = studentService.fetchAllStudent().stream()
		//		.map(data -> mapper.map(data, StudentDto.class)).collect(Collectors.toList());
		return ResponseEntity.status(HttpStatus.OK).body(null);
	}
}
