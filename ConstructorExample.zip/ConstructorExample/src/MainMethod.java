
public class MainMethod {

	public static void main(String[] args) {

		Addition ad = new Addition();
		Addition ad1 = new Addition(5,5);
		ad1.print();
	}

}
