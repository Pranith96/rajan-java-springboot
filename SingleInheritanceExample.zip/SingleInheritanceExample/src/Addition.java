
public class Addition {

	public void add() {
		System.out.println("Add method");
	}

	public void print() {
		System.out.println("Print method");
	}

}
