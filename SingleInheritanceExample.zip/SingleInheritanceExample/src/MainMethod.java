
public class MainMethod {

	public static void main(String[] args) {
		Summation sum = new Summation();
		sum.add();
		sum.draw();
		sum.print();
	}
}
