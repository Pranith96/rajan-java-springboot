
public class Summation extends Addition {

	public void draw() {
		System.out.println("draw method");
	}
}
