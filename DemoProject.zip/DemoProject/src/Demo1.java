
public class Demo1 {

	public void hello() {
		System.out.println("hello");
	}
	
	public static void hi() {
		Demo2 demo2 = new Demo2();
		demo2.display();
		System.out.println("Hi");
	}
}
