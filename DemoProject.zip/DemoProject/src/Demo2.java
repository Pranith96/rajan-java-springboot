
public class Demo2 {

	public void display() {
		System.out.println("display");
	}
	
}
